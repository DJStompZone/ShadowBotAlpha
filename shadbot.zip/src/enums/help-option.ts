export enum HelpOption {
    COMMANDS = 'COMMANDS',
    PERMISSIONS = 'PERMISSIONS',
    FAQ = 'FAQ',
}
