export enum InfoOption {
    ABOUT = 'ABOUT',
    TRANSLATE = 'TRANSLATE',
    DEV = 'DEV',
}
