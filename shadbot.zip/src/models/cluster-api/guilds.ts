export interface GetGuildsResponse {
    guilds: string[];
}
