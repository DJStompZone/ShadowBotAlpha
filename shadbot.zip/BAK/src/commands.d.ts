import { Message } from 'discord.js';
export default function helpCommand(message: Message): any;
