import './commands/ping';
