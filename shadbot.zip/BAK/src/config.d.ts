declare const _default: {
    guildId: any;
    clientId: any;
    prefix: string;
    token: string;
    intents: any[];
};
export default _default;
