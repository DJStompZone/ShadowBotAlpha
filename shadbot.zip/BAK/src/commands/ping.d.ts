import { SlashCommandBuilder } from '@discordjs/builders';
declare const _default: {
    data: SlashCommandBuilder;
    execute(interaction: any): Promise<void>;
};
export default _default;
